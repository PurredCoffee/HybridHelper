namespace Celeste.Mod.HybridHelper;

public class HybridHelperModuleSession : EverestModuleSession {

}