namespace Celeste.Mod.HybridHelper;

public class HybridHelperModuleSettings : EverestModuleSettings {
    [SettingSubText("Ensure that you have paceping disabled")]
    public bool RandomizeGoldenBerries { get; set; } = false;
    [SettingSubText("Comma separated list of rooms with checkpoints to ignore")]
    public string IgnoreCheckpoints { get; set; } = "";
}