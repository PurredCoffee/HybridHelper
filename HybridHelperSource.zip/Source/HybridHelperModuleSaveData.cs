namespace Celeste.Mod.HybridHelper;

public class HybridHelperModuleSaveData : EverestModuleSaveData {

}